Export as JAR file with sources...

RULES:

Need validator Interface and implementation if going to use DI
Using Convention over Configuration [CoC]
that is...the following "like" naming convention:
	ProductValidator.java is interface
	ProductValidatorImpl.java is implementation
	
	Where Product is the domain Object being validated
The files[Validator files] also need to be in the same package


 