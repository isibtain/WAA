
Servlet based Model 1 Application

Context listener invokes factory for DataFacade
TestDataImpl is Singleton

final List of Coffees is "COLOR" coded to exercise JSTL

Uses "virtual" URIs [e.g.,  /action/login ]...to hide source details

See Database.java for users for login

